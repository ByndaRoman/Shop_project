<?php
	include "database.php";
	
	$result = mysqli_query($connect, "SELECT * FROM `tovari` WHERE id = 2");
	?>

<!DOCTYPE html>
<html>
<head>
<title>Інтернет магазин</title>

<link href="css/cssfilesite.css" rel='stylesheet' type='text/css' />

<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@200;300;400;500;600;700&display=swap" rel="stylesheet" type='text/css'>

<meta charset="utf-8">

<link rel="stylesheet" href="css/bootstrap-reboot.min.css">

<link rel="stylesheet" href="css/bootstrap-grid.min.css">

<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
</head>

<body>
<header>
	<img src="images/logo.png">
	<nav>
		<ul class="nav_links">
			<li><a href='index.php'>Головна</li>
			<li><a href='index_aboutus.php'>Про нас</li>
			<li><a href='#'>Мій кошик</li>
			
			<li><a href='register/register.php'>Реєстрація</li>
			<li><a href='register/login.php'>Увійти</li>

			<li><a > </li>
		</ul>
	</nav>
</header>

<div class="container mt-5">
	<div class="row">
<?php
	$tovar = mysqli_fetch_assoc($result)
	?>
		<h1><?php echo $tovar['product_name'];?></h1>
		<div class="col-md-3">
			<div class="product">
				<div class="image_price">
					<img src="images/<?php echo $tovar['image'];?>" alt="">
				</div>
				
				<div class="info">
					<div class="info-price">
						<span class="price"><?php echo $tovar['price'];?><small>грн <?php echo $tovar['odinitcha_tovaru'];?></small></span>
					</div>
				</div>
			</div>
		</div>

	</div>
</div>

<footer class="footer-site">
<div class="container">
	<div class="row">
		<div class="text 1">
			<h2>м.Чернівці</h2>
			<li>Проспект незалежності 117</li>
		</div>
		<div class="text 2">
			<li>Графік роботи:</li>
			<li>Пн-Пц: 8:30 - 19:00</li>
			<li>Сб: 9:00 - 17:00</li>
			<li>Нд: Вихідний</li>
		</div>
		<div class="text 3">
			<li>Номер телеф. +380953619675</li>
			<li>Электронная почта: palyanicha69@gmail.com</li>
		</div>
		<div class="text 4 created">
			<h5 align="center"><small>&copy;</small> Binda Roman 2022</h5>
		</div>
	</div>
</div>
 </footer>
</body>		
</html>


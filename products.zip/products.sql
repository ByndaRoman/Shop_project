-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Май 13 2022 г., 19:17
-- Версия сервера: 10.5.11-MariaDB
-- Версия PHP: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `products`
--

-- --------------------------------------------------------

--
-- Структура таблицы `postachalnik`
--

CREATE TABLE `postachalnik` (
  `ID` int UNSIGNED NOT NULL,
  `Місяць_продажу` text NOT NULL,
  `Назва_поставника` text NOT NULL,
  `Адреса_поставника` text NOT NULL,
  `Телефон_поставника` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `postachalnik`
--

INSERT INTO `postachalnik` (`ID`, `Місяць_продажу`, `Назва_поставника`, `Адреса_поставника`, `Телефон_поставника`) VALUES
(1, '23.03', 'Вопак', 'Vopak.lutsk@mail.ru', '0 (33 42)5-32-23'),
(2, '23.03', 'Пакко', 'pakko.kovel@rambler.ru', '0 (31 42)3-74-23'),
(3, '23.03', 'Наш Край', 'nashkrai@mail.ru', '0 (32 52)2-54-33'),
(4, '25.03', 'Мережа продуктів', 'mer.prod@mail.ru', '0 (35 42)3-11-13'),
(5, '25.03', 'Молочна країна', 'molo4.kra@rambler.ru', '0 (36 42)4-54-23'),
(6, '27.03', 'Яник', 'yanuk@mail.ru', '0 (39 42)3-34-32'),
(7, '27.03', 'Бруно', 'bruno@rambler.ru', '0 (40 42)4-75-35'),
(8, '27.03', 'Фруктовшина', 'fruktov4ina@mail.ru', '0 (50 42)4-54-23'),
(9, '27.03', 'Садочок', 'sado4ok@mail.ru', '0 (30 42)3-57-23'),
(10, '27.03', 'Ням-Ням', 'n9m.n9m@rambler.ru', '0 (46 42)2-54-23');
-- --------------------------------------------------------

--
-- Структура таблицы `postuplenya_tovariv`
--

CREATE TABLE `postuplenya_tovariv` (
  `ID` int UNSIGNED NOT NULL,
  `Дата_поступлення` date NOT NULL,
  `Ціна_придбання_товару_за_одиницю` decimal(20,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


--
-- Дамп данных таблицы `postuplenya_tovariv`
--

INSERT INTO `postuplenya_tovariv` (`ID`, `Дата_поступлення`, `Ціна_придбання_товару_за_одиницю`) VALUES
(1, '2022-01-16', '3.00'),
(2, '2022-01-16', '2.00'),
(3, '2022-01-17', '3.00'),
(4, '2022-01-17', '4.00'),
(5, '2022-01-18', '5.00'),
(6, '2022-01-18', '4.00'),
(7, '2022-01-19', '4.00'),
(8, '2022-01-20', '1.00'),
(9, '2022-01-20', '1.00'),
(10, '2022-01-21', '6.00');

-- --------------------------------------------------------

--
-- Структура таблицы `prodazh_tovariv`
--

CREATE TABLE `prodazh_tovariv` (
  `ID` int UNSIGNED NOT NULL,
  `Місяць_продажу` text NOT NULL,
  `Продана_кількість_за_місяць` int NOT NULL,
  `Ціна_продажу_товару` decimal(20,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `prodazh_tovariv`
--

INSERT INTO `prodazh_tovariv` (`ID`, `Місяць_продажу`, `Продана_кількість_за_місяць`, `Ціна_продажу_товару`) VALUES
(1, '23.03', '130', '390.00'),
(2, '23.03', '120', '240.00'),
(3, '23.03', '40', '120.00'),
(4, '25.03', '50', '200.00'),
(5, '25.03', '55', '275.00'),
(6, '25.03', '40', '160.00'),
(7, '27.03', '40', '160.00'),
(8, '27.03', '290', '290.00'),
(9, '27.03', '100', '300.00'),
(10, '27.03', '40', '240.00');

-- --------------------------------------------------------

--
-- Структура таблицы `tovari`
--

CREATE TABLE `tovari` (
  `ID` int UNSIGNED NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `quantity` int NOT NULL
  `odinitcha_tovaru` varchar(15) NOT NULL,
  `price` decimal(20,2) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `tovari`
--

INSERT INTO `users` (`ID`, `product_name`, `quantity`, `odinitcha_tovaru`, `price`, `image`) VALUES
(1, 'Мандаріни', '175', 'за кг.', '96.00', 'image1.png'),
(2, 'Апельсин', '150', 'за кг.', '45.00', 'image2.png'),
(3, 'Банан', '55', 'за кг.', '35.00', 'image3.png'),
(4, 'Молоко', '70', 'за шт.', '24.00', 'image4.png'),
(5, 'Сметана', '60', 'за шт.', '35.00', 'image5.png'),
(6, 'Кефір', '50', 'за шт.', '29.00', 'image6.png'),
(7, 'Ряжанка', '50', 'за шт.', '17.00', 'image7.png'),
(8, 'Помідор', '299', 'за кг.', '51.00', 'image8.png'),
(9, 'Хліб', '100', 'за шт.', '21.00', 'image9.png'),
(10, 'Йогурт', '50', 'за шт.', '26.00', 'image10.png');

-- --------------------------------------------------------
--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `postuplenya_tovariv`
--
ALTER TABLE `postuplenya_tovariv`
  ADD CONSTRAINT `postuplenya_tovariv_ibfk_1` FOREIGN KEY (`ID`) REFERENCES `postachalnik` (`ID`);
ALTER TABLE `postuplenya_tovariv`
  ADD CONSTRAINT `postuplenya_tovariv_ibfk_2` FOREIGN KEY (`ID`) REFERENCES `prodazh_tovariv` (`ID`);
ALTER TABLE `postuplenya_tovariv`
  ADD CONSTRAINT `postuplenya_tovariv_ibfk_3` FOREIGN KEY (`ID`) REFERENCES `prodazh_tovariv` (`ID`);
ALTER TABLE `postuplenya_tovariv`
  ADD CONSTRAINT `postuplenya_tovariv_ibfk_4` FOREIGN KEY (`ID`) REFERENCES `tovari` (`ID`);

--
-- Ограничения внешнего ключа таблицы `tovari`
--
ALTER TABLE `tovari`
  ADD CONSTRAINT `tovari_ibfk_1` FOREIGN KEY (`ID`) REFERENCES `prodazh_tovariv` (`ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php

$part1_ip = "127.0.0.1";
$part2_name = "root";
$part3_p = "";
$part4_db = "products";

$connect = mysqli_connect($part1_ip, $part2_name, $part3_p, $part4_db);
$rest = mysqli_query($connect, "SELECT * FROM 'tovari' ORDER BY id");


if ($connect == false)
{
	echo "Помилка з підключенням";
}
?>